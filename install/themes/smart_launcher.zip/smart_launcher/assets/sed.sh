#!/bin/sh
sed -i \
         -e 's/#eeeeee/rgb(0%,0%,0%)/g' \
         -e 's/#111111/rgb(100%,100%,100%)/g' \
    -e 's/#ccddff/rgb(50%,0%,0%)/g' \
     -e 's/#3366cc/rgb(0%,50%,0%)/g' \
     -e 's/#ccddff/rgb(50%,0%,50%)/g' \
     -e 's/#111111/rgb(0%,0%,50%)/g' \
	"$@"
